from vec2d import Point
from vec2d import Vec2D
import math


def orient2d(a, b, c):
    '''
    Note that you will need this function only if you plan
    to code up the optional question listed in section 2.4.2
    
    Parameters
    ----------
        a : Point object
        b : Point object
        c : Point object
        
    Returns
    --------
        Integer 1/1/0
        Returns 1 if points are oriented in the 
        counter clockwise direction -1 if clockwise
        and 0 if collinear
        
    '''
    # Signed area of triangle formed by a,b,c
    s_a = (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)
    
    # Orientation
    result = 1 if s_a > 0 else -1 if s_a < 0 else 0
    
    return result


class ConvexPolygon:

    def __init__(self, points):
        """
        Initializing the variables that will be used

        Parameters
        ----------
        points : list
            List that contains the points of the polygon.

        Returns
        -------
        None.
        """
        #number of verticies, verticies, temperary verticies in order
        #to get edges
        self.nverts = len(points)
        self.verts = points
        self.tempverts = self.verts.copy()
        self.tempverts.append(self.tempverts[0])
        self.edges = [0] * self.nverts
        for i in range(self.nverts):
            self.edges[i] = Vec2D.__sub__(self.tempverts[i+1], self.tempverts[i])


    def __str__(self):

        nv = 'No. of Vertices: '+str(self.nverts)+'\n'
        vs = "Vertices "+" ".join([v.__str__() + ', ' for v in self.verts]) + '\n'
        es = "Edges "+ " ".join([e.__str__() + ', ' for e in self.edges]) 
        return nv + vs + es

    def get_centroid(self):
        """
        Returns the centeroid of the polygon from points inputed.

        Returns
        -------
        Point
            Centeroid of the polygon.
        """
        #initializing variables that will be used
        A  = 0
        cx = 0
        cy = 0
        nv = self.nverts
        vs = self.tempverts

        #calculating A that will be used in the later calculations
        for i in range(nv):
            A += ( 0.5 * (vs[i].x * vs[i+1].y - vs[i+1].x * vs[i].y))
        #calculating centeroid x and y values and returning as a Point
        for i in range(nv):
            cx += ((1/(6*A)) * ((vs[i].x + vs[i+1].x) * 
                                (vs[i].x * vs[i+1].y - vs[i+1].x * vs[i].y)))
            cy += ((1/(6*A)) * ((vs[i].y + vs[i+1].y) * 
                                (vs[i].x * vs[i+1].y - vs[i+1].x * vs[i].y)))
        return Point(cx,cy)
    
    def translate(self, vector):
        """
        Translates the polygon in the direction and magnitude of a vector.

        Parameters
        ----------
        vector : Vec2D
            Vector for direction and magnitude that polyogn will translated.

        Returns
        -------
        None.
        """
        #itereates through each point and shifts it
        for i in range(self.nverts):
            self.verts[i] += vector
    
    def rotate(self, rad, pivot = None):
        """
        Rotates the polygon by theta around a pivot.

        Parameters
        ----------
        rad : (int , float)
            The radians that the polygon will be turned.
        pivot : Point, optional
            Optional pivot point. The default is None.

        Returns
        -------
        None.
        """
        #sets pivot to centroid if none is given
        if pivot == None:
            pivot = ConvexPolygon.get_centroid(self)
        #defining variable for cleaner code
        vs = self.verts
        ##iterates through the current points and moves them to their new 
        #location by updating the x and y then sets them as Point
        for i in range(self.nverts):
            xnew = (math.cos(rad) * (vs[i].x - pivot.x) - math.sin(rad)
                    * (vs[i].y - pivot.y) + pivot.x)
            ynew = (math.sin(rad) * (vs[i].x - pivot.x) + math.cos(rad)
                    * (vs[i].y - pivot.y) + pivot.y)
            self.verts[i] = Point(xnew,ynew)
            
        #updating edges
        ConvexPolygon.__init__(self,self.verts)
        #print(ConvexPolygon.get_centroid(self))
            
    def scale(self, sx, sy):
        """
        Scales the polygon by an ammount.

        Parameters
        ----------
        sx : (int, float)
            x distance that the point will be scaled.
        sy : (int, float)
            y distance that the point will be scaled.

        Returns
        -------
        None.
        """
        #defining variables for cleaner code
        c = ConvexPolygon.get_centroid(self)
        vs = self.verts
        ##iterates through the current points and moves them to their new 
        #location by updating the x and y then sets them as Point
        for i in range(self.nverts):
            xnew = (sx * (vs[i].x - c.x) + c.x)
            ynew = (sy * (vs[i].y - c.y) + c.y)
            self.verts[i] = Point(xnew,ynew)
        #updating edges
        ConvexPolygon.__init__(self, self.verts)
        
    
    '''

    # Uncomment these lines if you'd like to run game.py
    
    @staticmethod
    def get_projections_minmax (ortho, obj_1, obj_2):

        # Edit from this line
        projections_obj_1 = [ortho * vert for vert in obj_1.verts]
        projections_obj_2 = [ortho * vert for vert in obj_2.verts]
        
        min_obj_1, max_obj_1 = min(projections_obj_1), max(projections_obj_1)
        min_obj_2, max_obj_2 = min(projections_obj_2), max(projections_obj_2)
        
        return min_obj_1, max_obj_1, min_obj_2, max_obj_2 
        
    

    def __and__(self, other):
        
        #Uses separating axes theorem to check for overlaps

        all_edges = self.edges + other.edges
        
        for edge in all_edges:

            ortho = edge.normal_ccw()
            
            min_self, max_self, min_other, max_other = self.get_projections_minmax(ortho, self, other) 
            
            # Check for overlaps in projection
            if min_self > max_other or max_self < min_other:
                
                # Gap found in projections and therefore Overlap cannot occur
                return False
            
        return True
    

    '''

if __name__=='__main__':
    from convexpolygon import ConvexPolygon as ngon
    from vec2d import Point as P
    from vec2d import Vec2D as V
    
    a = ngon([P(1,0), P(0,1), P(-1,0), P(0,-1)])
    print(a.get_centroid())
    a.rotate(math.pi/4.0)
    print(a.get_centroid())
    
    #a.translate(V(3,75))

    #a.scale(2,2)
    #print(a)
    

    pass
