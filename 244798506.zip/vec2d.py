import math

    
class Point:
    
    #initializing variables
    def __init__(self, x=0 , y=0):
        """
        Initializes variables

        Parameters
        ----------
        x : (int float), optional
            x position. The default is 0.
        y : (int, float), optional
            y position. The default is 0.

        Returns
        -------
        None.
        """
        self.x = x
        self.y = y
        
    #overiding addition
    def __add__(self, other):
        """
        Overides addition to add two points.

        Parameters
        ----------
        other : Point
            Second point input.

        Returns
        -------
        Point
            Addition output.
        """
        newx = self.x + other.x
        newy = self.y + other.y
        return Point(newx , newy)
    
    #overiding += addition
    def __iadd__(self, other):
        """
        Overides += addition to add two points.

        Parameters
        ----------
        other : Point
            Second point input.

        Returns
        -------
        Point
            Updated first point with second point added to it.
        """
        self.x += other.x
        self.y += other.y
        return Point(self.x , self.y)
    
    #overiding subtraction
    def __sub__(self,other):
        """
        Overides subtraction to subtract two points.

        Parameters
        ----------
        other : Point
            Second point input.
        Returns
        -------
        Point
            Subtraction output.
        """
        newx = self.x - other.x
        newy = self.y - other.y
        return Point(newx , newy)
    
    #overiding -= subtraction
    def __isub__(self, other):
        """
        Overides -= subtracton to subtract two points.

        Parameters
        ----------
        other : Point
            Second point input.

        Returns
        -------
        Point
            Updated first point with second point subtracted from it.
        """
        self.x -= other.x
        self.y -= other.y
        return Point(self.x , self.y)
    

    
    def __repr__(self):
        '''
        Returns user friendly string

        Returns
        -------
        str
            User friendly output of point.
        '''
        return 'x: ' + str(round(self.x,4)) + ' y: ' + str(round(self.y,4))

    def __str__(self):
        '''
        Returns user friendly string

        Returns
        -------
        str
            User friendly output of point.
        '''
        return 'x: ' + str(round(self.x,4)) + ' y: ' + str(round(self.y,4))

    pass
    
class Vec2D(Point):

    def __init__(self, a = None, b = None):
        """
        Initializes variables

        Parameters
        ----------
        a : (Point, float, int), optional
            First vector. The default is None.
        b : (Point, float, int), optional
            Second vector. The default is None.

        Returns
        -------
        None.
        """
        #Initializing if both inputs are None
        if a == None and b == None:
            self.x = 0
            self.y = 0
        #Initializing if one input is number and other is None
        elif isinstance(a, (float, int))  and b == None:
            self.x = a
            self.y = 0
        #Initializing if both inputs are number
        elif isinstance(a, (float, int)) and isinstance(b, (float, int)):
            self.x = a
            self.y = b
        #Initializing if both inputs are Points
        elif isinstance(a, Point) and isinstance(b, Point):
            self.x = b.x - a.x
            self.y = b.y - a.y
        #Initializing if one input is a Point and other is None
        elif isinstance(a, Point) and b == None:
            self.x = a.x
            self.y = a.y
            
    def __add__(self,other):
        """
        Overides addition to add two vectors.

        Parameters
        ----------
        other : Vec2D
            Second point input.

        Returns
        -------
        Vec2D
            Addition output.
        """
        newx = self.x + other.x
        newy = self.y + other.y
        return Vec2D(newx , newy)

    def __sub__(self,other):
        """
        Overides subtraction to subtract two vectors.

        Parameters
        ----------
        other : Vec2D
            Second point input.

        Returns
        -------
        Vec2D
            Subtraction output.
        """
        newx = self.x - other.x
        newy = self.y - other.y
        return Vec2D(newx , newy)
    
    def __mul__(self,other):
        """
        Overides multiplication to multiply two vectors.

        Parameters
        ----------
        other : Vec2D
            Second point input.

        Returns
        -------
        Vec2D
            Multiplication output.
        """
        #if both inputs are Vec2D
        if isinstance(self, Vec2D) and isinstance(other, Vec2D):
            return self.x * other.x + self.y * other.y
        #if one input is Vec2D and the other is Point
        if isinstance(self, Vec2D) and isinstance(other, Point):
            return self.x * other.x + self.y * other.y
        #if one input is Vec2D and the other is Point
        if isinstance(self, Point) and isinstance(other, Vec2D):
            return self.x * other.x + self.y * other.y
        #if one input is Vec2D and the other is scalar
        if isinstance(self, Vec2D) and isinstance(other, (int,float)):
            return Vec2D(self.x * other , self.y * other)
        #if one input is Vec2D and the other is scalar
        if isinstance(self, (int,float)) and isinstance(other, Vec2D):
            return Vec2D(self * other.x , self * other.y)
        
    def norm(self):
        """
        Calculates the norm of the vector

        Returns
        -------
        float
            The norm of the vector.
        """
        return float(math.sqrt(self.x**2 + self.y**2))
        
    def normal_ccw(self):
        """
        Finds orthogonal vector that is counter clock wise.

        Returns
        -------
        Vec2D
            The new vector that is orthogonal and ccw.
        """
        return Vec2D(-self.y, self.x)
        
        pass


if __name__=='__main__':
    from vec2d import Vec2D as V
    from vec2d import Point as P
    
    #a = V(3,4)
    
    #print(a.normal_ccw())
    #print(type(a))
    
    #b = P(4,2)
    #c = V()
    d = V(P(3,4),P(4,6))
    
    
    #print(a)
    #print(type(a))
    print(d)
    #print(type(d))
    
    pass

