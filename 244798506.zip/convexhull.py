import math
from convexpolygon import ConvexPolygon 
from vec2d import Point as P
from vec2d import Vec2D
from vis import create_vis_polygon

def area2 (a, b, c):
    '''
    
    Parameters
    ----------
    a : Point object
        Vertex of a triangle.
    b : Point object
        ertex of a triangle.
    c : Point object
        Vertex of a triangle.

    Returns
    -------
    Int/Float
        Signed area of triangle formed by points a,b,c.
    '''
    # Compute signed area
    return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)
    

def is_ccw(a, b, c):
    '''
    
    Parameters
    ----------
    a : Point object
    b : Point object
    c : Point object

    Returns
    -------
    Boolean
        Returns True if points are oriented in the 
        counter clockwise direction
    '''
    return area2(a,b,c) > 0


def get_leftmost_point (points):
    """
    Returns the point with the smallest x value and if two match then the
    smallest y value as well.

    Parameters
    ----------
    points : list
        List of points.

    Returns
    -------
    leftmost : Point
        Point that is leftmost from all the input points.
    """
    #initializing a point that is leftmost
    leftmost = points[0]
    #creating a loop to go through the points
    for i in range(len(points)):
        #if the x values match checks for smallest y value
        if points[i].x == leftmost.x:
            if points[i].y < leftmost.y:
                leftmost = points[i]
        #if not checks which has smallest x value
        if points[i].x < leftmost.x:
            leftmost = points[i]

    return leftmost


def get_convex_hull ( points ):
    """
    Gets the convex hull (list of points that surrounds others) from a list 
    of points.

    Parameters
    ----------
    points : list
        List of points.

    Returns
    -------
    ConvexPolygon
        Polygon that is made up of the convex points.
    """
    #initializing variables
    xleft = get_leftmost_point (points)
    chull_vertices = list()
    chull_vertices.append(xleft)
    xhull = xleft
    xend = points[0]
    
    #continuin the itereation until xend equals the first point
    while xend != chull_vertices[0]:
        #looping through all points
        for i in range(len(points)):
            #updating xend
            if is_ccw(xhull,points[i], xend) or (xhull == xend):
                xend = points[i]
      
        xhull = xend
        #breaking if xend equals the first point if not adding it to list
        if (xend.x == xleft.x) and (xend.y == xleft.y):
            return ConvexPolygon(chull_vertices)
        
        chull_vertices.append(xend)
       
def plot_convex_hull ( points, chull, filename = None ):
    '''  

    Parameters
    ----------
    points : List
        a List of Point objects.
    chull : ConvexPolygon
        ConvexPolygon object that is a convex hull.
    filename : string, optional
        DFilename for saving the plot.

    Returns
    -------
    None.

    '''

    import matplotlib.pyplot as plt
    import seaborn as sns

    # Create plot object
    fig, ax = plt.subplots()

    # Get x coordinates and y coordinates
    xps = [p.x for p in points]
    yps = [p.y for p in points]

    # Get x,y coordinates of polygon vertices
    poly_x = [p.x for p in chull.verts]
    poly_y = [p.y for p in chull.verts]

    # Closing the polygon
    poly_x.append(chull.verts[0].x)
    poly_y.append(chull.verts[0].y)
    
    # Scatter plot of points
    ax.scatter(xps, yps, c = '#000000', s = 15)

    # Plot convex hull
    ax.plot(poly_x, poly_y, linewidth = 3)
    p = create_vis_polygon(chull)  
    ax.add_patch(p)

    # left most point
    ax.scatter(poly_x[0], poly_y[0], c = 'r', s = 25)
    
    ax.set_xlabel('x', fontsize=20)
    ax.set_ylabel('y', fontsize=20)
    
    plt.tight_layout()

    if filename is not None:
        plt.savefig(filename)
    else:
        plt.show()

    
if __name__=='__main__':
    
    pts  = [P(2,4), P(1,2), P(2,5), P(4,5), P(2,6)]
    pts2  = [P(1,4), P(1,2), P(2,5), P(4,5), P(2,6)]
    get_leftmost_point(pts)
    print(get_convex_hull(pts))
    
    
    #plot_convex_hull(pts, get_convex_hull(pts))
    #print(get_leftmost_point([P(-1,0), P(-1,3), P(-1,5), P(-1,7)]))
